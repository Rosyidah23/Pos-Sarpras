<?php $__env->startSection('title','Beranda Siswa | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <?php if(session('status')): ?>
            <p class="alert-success"><?php echo e(session('status')); ?></p>
        <?php endif; ?>

        <header class="head">
            <div>
                <p class="eyebrow"><?php echo e(ucfirst(now()->translatedFormat('l, d F Y'))); ?></p>
                <h1>Hai, <?php echo e(auth()->user()->name); ?>! 👋</h1>
                <p>Kalau ada fasilitas bermasalah, lapor biar cepat dibenerin.</p>
            </div>
        </header>

        <div class="welcome">
            <div class="hello">
                <p>Bikin sekolah makin nyaman</p>
                <h2>Ada yang rusak?</h2>
                <p>Foto kondisinya, pilih ruangannya, jelaskan singkat. Beres.</p>
                <a class="btn primary" href="<?php echo e(route('reports.create')); ?>">Buat laporan baru ↗</a>
            </div>
            <div class="denah">
                <h3>📍 Denah asli sekolah</h3>
                <p>Denah SMKN 5 Surakarta</p>
                <img src="<?php echo e(asset('images/denah-smkn5.png')); ?>" alt="Denah SMKN 5 Surakarta">
                <a class="btn" href="<?php echo e(route('map')); ?>">Buka denah asli →</a>
            </div>
        </div>

        <div class="stats">
            <div class="stat" style="--tone:var(--yellow)"><i></i><strong><?php echo e($counts['menunggu']); ?></strong><small>Menunggu dicek</small></div>
            <div class="stat" style="--tone:var(--blue)"><i></i><strong><?php echo e($counts['diproses']); ?></strong><small>Sedang diproses</small></div>
            <div class="stat" style="--tone:var(--mint)"><i></i><strong><?php echo e($counts['selesai']); ?></strong><small>Sudah selesai</small></div>
            <div class="stat" style="--tone:var(--coral)"><i></i><strong><?php echo e($counts['ditolak']); ?></strong><small>Ditolak</small></div>
        </div>

        <div class="reports-head">
            <h3>Laporan terbaru</h3>
            <a class="see-all" href="<?php echo e(route('reports.history')); ?>">Lihat semua riwayat →</a>
        </div>
        <div class="reports">
            <?php $__empty_1 = true; $__currentLoopData = $recentReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="report">
                    <b><?php echo e($report->title); ?><small>#<?php echo e($report->code); ?></small>
                        <span class="report-desc" title="<?php echo e($report->description); ?>"><?php echo e($report->description); ?></span>
                    </b>
                    <span class="tag" title="<?php echo e($report->category->name ?? '-'); ?>"><?php echo e($report->category->name ?? '-'); ?></span>
                    <span class="muted" title="<?php echo e($report->location->name ?? '-'); ?>"><?php echo e($report->location->name ?? '-'); ?></span>
                    <span class="status"><?php echo e(ucfirst($report->status)); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="report">
                    <b>Belum ada laporan.<small>Yuk buat laporan pertamamu.</small></b>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/student/dashboard.blade.php ENDPATH**/ ?>
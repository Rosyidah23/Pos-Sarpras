<?php $__env->startSection('title','Rekap & Cetak Laporan | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'admin.recap'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <div class="no-print">
            <header class="head">
                <div>
                    <p class="eyebrow">REKAP & CETAK</p>
                    <h1>Rekap laporan.</h1>
                    <p>Pilih rentang tanggal, lalu cetak atau download sebagai CSV.</p>
                </div>
                <div class="head-actions">
                    <button type="button" class="btn primary" data-print>🖨 Cetak</button>
                    <a class="btn soft" href="<?php echo e(route('admin.export', array_filter(['from' => $from, 'to' => $to, 'status' => $status]))); ?>">⇩ Download CSV</a>
                </div>
            </header>

            <?php if($errors->any()): ?>
                <p class="alert-error"><?php echo e($errors->first()); ?></p>
            <?php endif; ?>

            <form method="GET" action="<?php echo e(route('admin.recap')); ?>" class="date-filter">
                <div class="field">
                    <label for="from">Dari tanggal</label>
                    <input id="from" type="date" name="from" value="<?php echo e($from); ?>">
                </div>
                <div class="field">
                    <label for="to">Sampai tanggal</label>
                    <input id="to" type="date" name="to" value="<?php echo e($to); ?>">
                </div>
                <div class="field">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="">Semua status</option>
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s); ?>" <?php if($status === $s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button class="btn primary" type="submit">Tampilkan</button>
                <?php if($from || $to || $status): ?>
                    <a class="btn soft" href="<?php echo e(route('admin.recap')); ?>">Reset</a>
                <?php endif; ?>
            </form>

            <div class="filter-bar">
                <?php $__currentLoopData = $presets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="chip <?php echo e($from === $range['from'] && $to === $range['to'] ? 'chip-active' : ''); ?>"
                       href="<?php echo e(route('admin.recap', array_filter($range + ['status' => $status]))); ?>"><?php echo e($label); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <section class="print-sheet">
            <div class="sheet-head">
                <img src="<?php echo e(asset('images/logo-smkn5.png')); ?>" alt="" class="sheet-logo">
                <div>
                    <h2>Rekap Laporan Sarana & Prasarana</h2>
                    <p>SMK Negeri 5 Surakarta</p>
                </div>
            </div>

            <dl class="sheet-meta">
                <div><dt>Periode</dt><dd><?php echo e($periodLabel); ?></dd></div>
                <div><dt>Status</dt><dd><?php echo e($status ? ucfirst($status) : 'Semua status'); ?></dd></div>
                <div><dt>Dicetak</dt><dd><?php echo e(now()->translatedFormat('d F Y, H:i')); ?> oleh <?php echo e(auth()->user()->name); ?></dd></div>
                <div>
                    <dt>Total</dt>
                    <dd>
                        <?php echo e($reports->count()); ?> laporan
                        <?php if($reports->isNotEmpty()): ?>
                            (<?php echo e(collect($statuses)->map(fn ($s) => ucfirst($s).' '.($summary[$s] ?? 0))->join(', ')); ?>)
                        <?php endif; ?>
                    </dd>
                </div>
            </dl>

            <table class="recap-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Kode</th>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Lokasi</th>
                        <th>Pelapor</th>
                        <th>Status</th>
                        <th>Catatan petugas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class="nowrap"><?php echo e($report->created_at->format('d/m/Y H:i')); ?></td>
                            <td class="nowrap"><?php echo e($report->code); ?></td>
                            <td><?php echo e($report->title); ?></td>
                            <td><?php echo e($report->category->name ?? '-'); ?></td>
                            <td><?php echo e($report->location->name ?? '-'); ?></td>
                            <td><?php echo e($report->user->name ?? '-'); ?></td>
                            <td><?php echo e(ucfirst($report->status)); ?></td>
                            <td><?php echo e($report->follow_up_note ?: '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="recap-empty">Tidak ada laporan pada periode ini.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="sheet-sign">
                <p>Surakarta, <?php echo e(now()->translatedFormat('d F Y')); ?></p>
                <p>Petugas Sarpras</p>
                <p class="sign-name"><?php echo e(auth()->user()->name); ?></p>
            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/admin/recap.blade.php ENDPATH**/ ?>
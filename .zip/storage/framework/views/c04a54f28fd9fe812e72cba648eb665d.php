<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo $__env->yieldContent('title','POS-SARPRAS'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/pos-sarpras.css')); ?>?v=<?php echo e(filemtime(public_path('css/pos-sarpras.css'))); ?>">
</head>
<body>
    <nav class="top">
        <?php if(auth()->guard()->check()): ?>
            <button type="button" class="nav-toggle" aria-label="Buka menu" aria-controls="sidebar" aria-expanded="false">
                <span></span><span></span><span></span>
            </button>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <img src="<?php echo e(asset('images/logo-smkn5.png')); ?>?v=<?php echo e(filemtime(public_path('images/logo-smkn5.png'))); ?>" alt="Logo SMKN 5 Surakarta" class="top-logo">
        <?php endif; ?>
        <b>POS-SARPRAS <span class="top-sep">·</span> SMKN 5 Surakarta</b>
        <?php if(auth()->guard()->check()): ?>
            <span class="top-role"><?php echo e(auth()->user()->isPetugas() ? 'Petugas' : 'Siswa'); ?></span>
            <a href="<?php echo e(route('logout')); ?>" class="top-logout">Keluar</a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">Masuk</a>
        <?php endif; ?>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <?php if(auth()->guard()->check()): ?>
        <div class="side-backdrop"></div>
    <?php endif; ?>

    <div id="toast" class="toast"></div>
    <script src="<?php echo e(asset('js/pos-sarpras.js')); ?>?v=<?php echo e(filemtime(public_path('js/pos-sarpras.js'))); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>
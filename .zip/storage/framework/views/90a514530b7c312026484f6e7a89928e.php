<?php
    $navUser = auth()->user();
    $isPetugas = $navUser && $navUser->isPetugas();
    $initials = $navUser
        ? mb_strtoupper(collect(explode(' ', $navUser->name))->filter()->map(fn ($p) => mb_substr($p, 0, 1))->take(2)->join(''))
        : '?';
    $active = $active ?? null;
?>
<aside class="side" id="sidebar">
    <div class="side-role">
        <img src="<?php echo e(asset('images/logo-smkn5.png')); ?>?v=<?php echo e(filemtime(public_path('images/logo-smkn5.png'))); ?>" alt="Logo SMKN 5 Surakarta" class="side-logo">
        <span class="side-role-badge"><?php echo e($isPetugas ? 'Petugas Sarpras' : 'Siswa / Pelapor'); ?></span>
    </div>

    <div class="nav-group">
        <div class="label">Menu utama</div>

        <?php if($isPetugas): ?>
            <a class="nav <?php echo e($active === 'admin.dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">⌂ &nbsp; Ringkasan</a>
            <a class="nav <?php echo e($active === 'admin.reports' ? 'active' : ''); ?>" href="<?php echo e(route('admin.reports')); ?>">✓ &nbsp; Verifikasi Laporan</a>
            <a class="nav <?php echo e($active === 'admin.recap' ? 'active' : ''); ?>" href="<?php echo e(route('admin.recap')); ?>">🖨 &nbsp; Rekap & Cetak</a>
        <?php else: ?>
            <a class="nav <?php echo e($active === 'dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">⌂ &nbsp; Beranda</a>
            <a class="nav <?php echo e($active === 'reports.create' ? 'active' : ''); ?>" href="<?php echo e(route('reports.create')); ?>">＋ &nbsp; Buat laporan</a>
            <a class="nav <?php echo e($active === 'map' ? 'active' : ''); ?>" href="<?php echo e(route('map')); ?>">⌖ &nbsp; Denah asli</a>
            <a class="nav <?php echo e($active === 'reports.history' ? 'active' : ''); ?>" href="<?php echo e(route('reports.history')); ?>">▣ &nbsp; Riwayat laporan</a>
        <?php endif; ?>
    </div>

    <?php if($isPetugas): ?>
        <div class="nav-group">
            <div class="label">Master data</div>
            <a class="nav <?php echo e($active === 'admin.categories' ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories')); ?>">☰ &nbsp; Kategori kerusakan</a>
            <a class="nav <?php echo e($active === 'admin.locations' ? 'active' : ''); ?>" href="<?php echo e(route('admin.locations')); ?>">📍 &nbsp; Lokasi / ruangan</a>
            <a class="nav <?php echo e($active === 'admin.accounts' ? 'active' : ''); ?>" href="<?php echo e(route('admin.accounts')); ?>">👤 &nbsp; Akun siswa</a>
        </div>
    <?php endif; ?>

    <a class="nav nav-logout" href="<?php echo e(route('logout')); ?>">↪ &nbsp; Keluar</a>

    <?php if($navUser): ?>
        <div class="user">
            <div class="avatar"><?php echo e($initials); ?></div>
            <div>
                <b><?php echo e($navUser->name); ?></b>
                <small><?php echo e($isPetugas ? 'Petugas Sarpras' : 'Siswa'); ?></small>
            </div>
        </div>
    <?php endif; ?>
</aside>
<?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Buat Laporan | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'reports.create'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <header class="head">
            <div>
                <p class="eyebrow">LAPORAN BARU</p>
                <h1>Ceritakan masalahnya.</h1>
                <p>Nggak perlu bahasa resmi, tulis seperti menjelaskan ke guru.</p>
            </div>
            <a class="btn soft" href="<?php echo e(route('dashboard')); ?>">← Kembali</a>
        </header>

        <div class="form-box">
            <form id="reportForm" method="POST" action="<?php echo e(route('reports.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="field">
                    <label>Yang rusak apa? *</label>
                    <select name="category_id" class="fancy-select" required>
                        <option value="">Pilih kategori...</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="field">
                    <label>Rusaknya di mana? *</label>
                    <?php if($selectedLocationId): ?>
                        <p class="field-hint">📍 Lokasi sudah keisi otomatis dari denah, tinggal diganti kalau salah.</p>
                    <?php endif; ?>
                    <select name="location_id" class="fancy-select" required>
                        <option value="">Pilih ruangan...</option>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location->id); ?>" <?php if(old('location_id', $selectedLocationId) == $location->id): echo 'selected'; endif; ?>><?php echo e($location->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="field">
                    <label>Judul laporan *</label>
                    <input name="title" required placeholder="Contoh: Lampu kelas mati tiga hari">
                </div>
                <div class="field">
                    <label>Jelaskan masalahnya *</label>
                    <textarea name="description" required placeholder="Contoh: Lampu baris depan mati sejak Senin."></textarea>
                </div>
                <div class="field">
                    <label>Foto bukti *</label>
                    <input name="photo" type="file" accept="image/*" required>
                </div>
                <button class="btn primary">Kirim laporan ↗</button>
            </form>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/student/report-form.blade.php ENDPATH**/ ?>
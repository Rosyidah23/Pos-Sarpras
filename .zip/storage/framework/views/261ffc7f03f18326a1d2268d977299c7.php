<?php $__env->startSection('title','Kategori Kerusakan | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'admin.categories'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <?php if(session('status')): ?>
            <p class="alert-success"><?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <p class="alert-error"><?php echo e(session('error')); ?></p>
        <?php endif; ?>

        <header class="head">
            <div>
                <p class="eyebrow">MASTER DATA</p>
                <h1>Kategori kerusakan.</h1>
                <p>Kategori ini muncul sebagai pilihan di form laporan siswa.</p>
            </div>
        </header>

        <div class="form-box master-form">
            <form method="POST" action="<?php echo e(route('admin.categories.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="field">
                    <label>Nama kategori baru</label>
                    <input name="name" required placeholder="Contoh: Jaringan Internet" value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="field-error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button class="btn primary">Tambah kategori</button>
            </form>
        </div>

        <div class="master-table">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="master-row">
                    <form method="POST" action="<?php echo e(route('admin.categories.update', $category)); ?>" class="master-edit">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <input name="name" value="<?php echo e($category->name); ?>">
                        <span class="muted"><?php echo e($category->reports_count); ?> laporan</span>
                        <button class="btn soft">Simpan</button>
                    </form>
                    <form method="POST" action="<?php echo e(route('admin.categories.destroy', $category)); ?>" onsubmit="return confirm('Hapus kategori <?php echo e($category->name); ?>?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn danger">Hapus</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">Belum ada kategori.</p>
            <?php endif; ?>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/admin/categories.blade.php ENDPATH**/ ?>
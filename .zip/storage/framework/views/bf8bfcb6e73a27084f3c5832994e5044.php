<?php $__env->startSection('title','Panel Petugas | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'admin.dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <header class="head">
            <div>
                <p class="eyebrow">PUSAT KENDALI PETUGAS</p>
                <h1>Semua laporan terlihat.</h1>
                <p>Atur laporan sampai selesai.</p>
            </div>
            <a class="btn primary" href="<?php echo e(route('admin.recap')); ?>">Rekap & Cetak</a>
        </header>

        <div class="welcome">
            <div class="hello">
                <p>Total laporan</p>
                <h2><?php echo e($total); ?></h2>
                <p><?php echo e($selesaiCount); ?> laporan sudah selesai ditangani.</p>
            </div>
            <div class="denah">
                <h3>Perlu dicek</h3>
                <h2 style="font-size:40px;margin-top:14px"><?php echo e($perluDicek); ?></h2>
                <p>Jangan sampai kelewat.</p>
            </div>
        </div>

        <div class="reports-head">
            <h3>Laporan terbaru</h3>
            <a class="see-all" href="<?php echo e(route('admin.reports')); ?>">Verifikasi semua laporan →</a>
        </div>
        <div class="reports">
            <?php $__empty_1 = true; $__currentLoopData = $recentReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="report">
                    <b><?php echo e($report->title); ?><small>#<?php echo e($report->code); ?> · <?php echo e($report->user->name ?? 'Tanpa nama'); ?></small>
                        <span class="report-desc" title="<?php echo e($report->description); ?>"><?php echo e($report->description); ?></span>
                    </b>
                    <span class="tag" title="<?php echo e($report->category->name ?? '-'); ?>"><?php echo e($report->category->name ?? '-'); ?></span>
                    <span class="muted" title="<?php echo e($report->location->name ?? '-'); ?>"><?php echo e($report->location->name ?? '-'); ?></span>
                    <span class="status"><?php echo e(ucfirst($report->status)); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="report">
                    <b>Belum ada laporan masuk.<small>Laporan dari siswa akan muncul di sini.</small></b>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
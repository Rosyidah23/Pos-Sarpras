<?php $__env->startSection('title','Lokasi / Ruangan | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'admin.locations'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <?php if(session('status')): ?>
            <p class="alert-success"><?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <p class="alert-error"><?php echo e(session('error')); ?></p>
        <?php endif; ?>

        <header class="head">
            <div>
                <p class="eyebrow">MASTER DATA</p>
                <h1>Lokasi / ruangan.</h1>
                <p>Daftar ruangan sesuai denah sekolah. Tambahkan kalau ada ruangan yang belum masuk daftar.</p>
            </div>
            <a class="btn soft" href="<?php echo e(route('map')); ?>">Lihat denah asli →</a>
        </header>

        <div class="form-box master-form">
            <form method="POST" action="<?php echo e(route('admin.locations.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="field">
                    <label>Nama ruangan baru</label>
                    <input name="name" required placeholder="Contoh: Rg 2.19" value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="field-error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button class="btn primary">Tambah lokasi</button>
            </form>
        </div>

        <div class="master-table">
            <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="master-row">
                    <form method="POST" action="<?php echo e(route('admin.locations.update', $location)); ?>" class="master-edit">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <input name="name" value="<?php echo e($location->name); ?>">
                        <span class="muted"><?php echo e($location->reports_count); ?> laporan</span>
                        <button class="btn soft">Simpan</button>
                    </form>
                    <form method="POST" action="<?php echo e(route('admin.locations.destroy', $location)); ?>" onsubmit="return confirm('Hapus lokasi <?php echo e($location->name); ?>?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn danger">Hapus</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">Belum ada lokasi.</p>
            <?php endif; ?>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/admin/locations.blade.php ENDPATH**/ ?>
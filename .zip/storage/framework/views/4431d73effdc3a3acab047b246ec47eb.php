<?php $__env->startSection('title','Denah Asli | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'map'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <header class="head">
            <div>
                <p class="eyebrow">DENAH ASLI SMKN 5 SURAKARTA</p>
                <h1>Cari tempatnya 📍</h1>
                <p>Klik ruangan pada denah asli untuk memilih lokasi masalah.</p>
            </div>
            <a class="btn soft" href="<?php echo e(route('reports.create')); ?>">Buat laporan →</a>
        </header>

        <div class="map-layout">
            <div class="map-board">
                <div class="map-frame">
                    <img id="schoolMap" src="<?php echo e(asset('images/'.$mapImage)); ?>" alt="Denah ruang SMK Negeri 5 Surakarta">
                    <?php $__currentLoopData = $hotspots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button
                            type="button"
                            class="map-hotspot"
                            style="left:<?php echo e($spot['left']); ?>%;top:<?php echo e($spot['top']); ?>%;width:<?php echo e($spot['width']); ?>%;height:<?php echo e($spot['height']); ?>%"
                            data-location-id="<?php echo e($spot['location_id']); ?>"
                            data-location-name="<?php echo e($spot['name']); ?>"
                            title="<?php echo e($spot['name']); ?>"
                        ></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <aside class="map-info">
                <small>LOKASI LAPORAN</small>
                <h2 id="roomTitle">Belum dipilih</h2>
                <p id="roomText">Klik ruangan pada denah asli, lalu lanjutkan ke form laporan.</p>
                <a class="btn" id="continueBtn" href="<?php echo e(route('reports.create')); ?>">Lanjut buat laporan ↗</a>
            </aside>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/student/map.blade.php ENDPATH**/ ?>
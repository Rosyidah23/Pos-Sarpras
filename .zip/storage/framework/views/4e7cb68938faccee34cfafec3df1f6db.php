<?php $__env->startSection('title','Akun Siswa | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'admin.accounts'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <?php if(session('status')): ?>
            <p class="alert-success"><?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <p class="alert-error"><?php echo e(session('error')); ?></p>
        <?php endif; ?>

        <header class="head">
            <div>
                <p class="eyebrow">MASTER DATA</p>
                <h1>Akun siswa / pelapor.</h1>
                <p>Siswa tidak bisa daftar sendiri, jadi akunnya dibuatkan di sini. Sampaikan email &amp; password ke siswanya langsung.</p>
            </div>
        </header>

        <div class="form-box account-form">
            <form method="POST" action="<?php echo e(route('admin.accounts.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="field">
                    <label>Nama siswa</label>
                    <input name="name" required placeholder="Contoh: Ahmad Zaki Prasetyo" value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="field-error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="field">
                    <label>Email / username</label>
                    <input name="email" type="email" required placeholder="Contoh: ahmad.zaki@smkn5surakarta.sch.id" value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="field-error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="field">
                    <label>Password awal</label>
                    <div class="pw-wrap">
                        <input id="newAccountPassword" name="password" type="password" required minlength="6" placeholder="Minimal 6 karakter">
                        <button type="button" class="pw-toggle" data-target="newAccountPassword" aria-label="Tampilkan password">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="field-error"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button type="button" class="btn soft pw-generate" data-target="newAccountPassword">Buatkan acak</button>
                </div>
                <button class="btn primary">Buat akun siswa</button>
            </form>
        </div>

        <div class="master-table">
            <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="account-row">
                    <div class="account-info">
                        <b><?php echo e($student->name); ?></b>
                        <small><?php echo e($student->email); ?> &middot; <?php echo e($student->reports_count); ?> laporan</small>
                    </div>

                    <form method="POST" action="<?php echo e(route('admin.accounts.reset-password', $student)); ?>" class="account-reset">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="pw-wrap">
                            <input id="pw-<?php echo e($student->id); ?>" name="password" type="password" minlength="6" required placeholder="Password baru">
                            <button type="button" class="pw-toggle" data-target="pw-<?php echo e($student->id); ?>" aria-label="Tampilkan password">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                            </button>
                        </div>
                        <button class="btn soft">Ganti password</button>
                    </form>

                    <form method="POST" action="<?php echo e(route('admin.accounts.destroy', $student)); ?>" onsubmit="return confirm('Hapus akun <?php echo e($student->name); ?>? Laporan yang sudah dibuat tetap tersimpan.')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn danger">Hapus</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">Belum ada akun siswa. Buat lewat form di atas.</p>
            <?php endif; ?>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/admin/accounts.blade.php ENDPATH**/ ?>
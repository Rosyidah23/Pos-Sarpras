<?php if($paginator->hasPages()): ?>
    <nav class="pager" aria-label="Halaman">
        <?php if($paginator->onFirstPage()): ?>
            <span class="chip chip-disabled">← Sebelumnya</span>
        <?php else: ?>
            <a class="chip" href="<?php echo e($paginator->previousPageUrl()); ?>">← Sebelumnya</a>
        <?php endif; ?>

        <span class="pager-info">Halaman <?php echo e($paginator->currentPage()); ?> dari <?php echo e($paginator->lastPage()); ?></span>

        <?php if($paginator->hasMorePages()): ?>
            <a class="chip" href="<?php echo e($paginator->nextPageUrl()); ?>">Berikutnya →</a>
        <?php else: ?>
            <span class="chip chip-disabled">Berikutnya →</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/partials/pager.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Verifikasi Laporan | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'admin.reports'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <?php if(session('status')): ?>
            <p class="alert-success"><?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <p class="alert-error"><?php echo e(session('error')); ?></p>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <p class="alert-error"><?php echo e($errors->first()); ?></p>
        <?php endif; ?>

        <header class="head">
            <div>
                <p class="eyebrow">VERIFIKASI LAPORAN</p>
                <h1>Tindak lanjuti laporan masuk.</h1>
                <p>Ubah status dan tambahkan catatan supaya pelapor tahu perkembangannya.</p>
            </div>
            <a class="btn soft" href="<?php echo e(route('admin.recap', array_filter(['from' => $from, 'to' => $to, 'status' => $statusFilter]))); ?>">🖨 Cetak / download rekap</a>
        </header>

        <form method="GET" action="<?php echo e(route('admin.reports')); ?>" class="date-filter">
            <div class="field">
                <label for="from">Dari tanggal</label>
                <input id="from" type="date" name="from" value="<?php echo e($from); ?>">
            </div>
            <div class="field">
                <label for="to">Sampai tanggal</label>
                <input id="to" type="date" name="to" value="<?php echo e($to); ?>">
            </div>
            <?php if($statusFilter): ?>
                <input type="hidden" name="status" value="<?php echo e($statusFilter); ?>">
            <?php endif; ?>
            <button class="btn primary" type="submit">Terapkan</button>
            <?php if($from || $to): ?>
                <a class="btn soft" href="<?php echo e(route('admin.reports', array_filter(['status' => $statusFilter]))); ?>">Reset tanggal</a>
            <?php endif; ?>
        </form>

        <div class="filter-bar">
            <a class="chip <?php echo e(!$statusFilter ? 'chip-active' : ''); ?>" href="<?php echo e(route('admin.reports', array_filter(['from' => $from, 'to' => $to]))); ?>">Semua</a>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="chip <?php echo e($statusFilter === $s ? 'chip-active' : ''); ?>" href="<?php echo e(route('admin.reports', array_filter(['from' => $from, 'to' => $to, 'status' => $s]))); ?>"><?php echo e(ucfirst($s)); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="verify-list">
            <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="verify-card">
                    <div class="verify-info">
                        <?php if($report->photo_path): ?>
                            <button type="button" class="verify-photo-btn photo-zoom" data-full="<?php echo e(asset('storage/'.$report->photo_path)); ?>">
                                <img class="verify-photo" src="<?php echo e(asset('storage/'.$report->photo_path)); ?>" alt="Foto bukti">
                            </button>
                        <?php endif; ?>
                        <div>
                            <b><?php echo e($report->title); ?></b>
                            <small>#<?php echo e($report->code); ?> · Dilaporkan oleh <?php echo e($report->user->name ?? 'Tanpa nama'); ?> · <?php echo e($report->created_at->translatedFormat('d M Y, H:i')); ?></small>
                            <p class="verify-desc"><?php echo e($report->description); ?></p>
                            <div class="verify-tags">
                                <span class="tag"><?php echo e($report->category->name ?? '-'); ?></span>
                                <span class="muted">📍 <?php echo e($report->location->name ?? '-'); ?></span>
                                <span class="status"><?php echo e(ucfirst($report->status)); ?></span>
                            </div>
                            <?php if($report->follow_up_note): ?>
                                <p class="verify-note">Catatan: <?php echo e($report->follow_up_note); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <form method="POST" action="<?php echo e(route('admin.reports.update', $report)); ?>" class="verify-form">
                        <?php echo csrf_field(); ?>
                        <select name="status" required>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s); ?>" <?php if($report->status === $s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input name="follow_up_note" value="<?php echo e($report->follow_up_note); ?>" placeholder="Catatan tindak lanjut (opsional)">
                        <button class="btn primary">Simpan</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="report">
                    <b><?php echo e($from || $to || $statusFilter ? 'Tidak ada laporan yang cocok dengan filter.' : 'Belum ada laporan.'); ?><small>Laporan dari siswa akan muncul di sini.</small></b>
                </div>
            <?php endif; ?>
        </div>

        <?php echo $__env->make('partials.pager', ['paginator' => $reports], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/admin/reports.blade.php ENDPATH**/ ?>
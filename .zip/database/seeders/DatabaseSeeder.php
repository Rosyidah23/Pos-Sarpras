<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Location;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Akun Petugas
        User::firstOrCreate(
            ['email' => 'petugas@smkn5surakarta.sch.id'],
            [
                'name' => 'Petugas Sarpras',
                'password' => Hash::make('password'),
                'role' => 'petugas',
            ]
        );

        // Akun Siswa 
        $students = [
            ['name' => 'Rosyidah Alif Hakimah', 'email' => 'siswa@smkn5surakarta.sch.id'], // akun demo utama
            ['name' => 'Ahmad Zaki Prasetyo', 'email' => 'ahmad.zaki@smkn5surakarta.sch.id'],
            ['name' => 'Bintang Aditya Nugraha', 'email' => 'bintang.aditya@smkn5surakarta.sch.id'],
            ['name' => 'Citra Ayu Lestari', 'email' => 'citra.ayu@smkn5surakarta.sch.id'],
            ['name' => 'Dewi Rahmawati', 'email' => 'dewi.rahmawati@smkn5surakarta.sch.id'],
            ['name' => 'Eka Putra Wibowo', 'email' => 'eka.putra@smkn5surakarta.sch.id'],
            ['name' => 'Fajar Nur Ramadhan', 'email' => 'fajar.nur@smkn5surakarta.sch.id'],
            ['name' => 'Galih Saputra', 'email' => 'galih.saputra@smkn5surakarta.sch.id'],
            ['name' => 'Hana Puspita Sari', 'email' => 'hana.puspita@smkn5surakarta.sch.id'],
            ['name' => 'Indah Permatasari', 'email' => 'indah.permata@smkn5surakarta.sch.id'],
            ['name' => 'Joko Widiyanto', 'email' => 'joko.widiyanto@smkn5surakarta.sch.id'],
        ];

        foreach ($students as $student) {
            User::firstOrCreate(
                ['email' => $student['email']],
                [
                    'name' => $student['name'],
                    'password' => Hash::make('password'),
                    'role' => 'siswa',
                ]
            );
        }

        // Kategori kerusakan
        foreach ([
            'Listrik & Lampu',
            'Kamar Mandi & Air',
            'Meja & Kursi',
            'Komputer & LCD',
            'Kebersihan',
            'Bangunan (Tembok, Atap, Lantai)',
            'Internet / WiFi',
            'Alat Praktik / Bengkel',
        ] as $name) {
            Category::firstOrCreate(['name' => $name]);
        }

        // Lokasi/ruangan sesuai Denah Ruang SMK Negeri 5 Surakarta
        $locations = [
            // Ruang kelas & lab lantai 1
            'Rg 1.01', 'Rg 1.02', 'Rg 1.03', 'Rg 1.04', 'Rg 1.05', 'Rg 1.06',
            'Rg 1.07', 'Rg 1.08', 'Rg 1.09', 'Rg 1.10', 'Rg 1.11', 'Rg 1.12',
            'Rg 1.18', 'Rg 1.19', 'Rg 1.20', 'Rg 1.21',
            // Ruang kelas & lab lantai 2
            'Rg 2.01 (AXIOO)', 'Rg 2.02 (AXIOO)', 'Rg 2.03 (AXIOO)', 'Rg 2.04', 'Rg 2.05', 'Rg 2.06',
            'Rg 2.07', 'Rg 2.08', 'Rg 2.09', 'Rg 2.10', 'Rg 2.11', 'Rg 2.12',
            'Rg 2.13', 'Rg 2.14', 'Rg 2.15', 'Rg 2.16', 'Rg 2.17', 'Rg 2.18',
            'Rg 2.20', 'Rg 2.21', 'Rg 2.22', 'Rg 2.23', 'Rg 2.24', 'Rg 2.25',
            // Jurusan Teknik Kendaraan Ringan & Listrik
            'RPS TKR', 'RPS TKP', 'RPS Teknik Otomotif', 'RPS Teknik Pemesinan',
            'RPS TSM 1', 'RPS TSM 2', 'RPS TSM 3',
            'Bengkel Listrik 2', 'Bengkel Listrik 3 (IML)', 'Bengkel Listrik 5', 'Bengkel Listrik 6 (ITL)', 'Bengkel DLE',
            'Lab. Fisika',
            // Elektronika
            'RPS Elektronika', 'Bengkel Elektro 1', 'Bengkel Elektro 2', 'Bengkel Elektro 3', 'Bengkel Elektro 4',
            'Bengkel Otomasi 1', 'Bengkel Otomasi 2', 'Bengkel SKE', 'Bengkel PSA', 'Bengkel SKT', 'Bengkel SKEE',
            // Teknik Pemesinan / ASM
            'Lab. ASM 1 (R.1.13)', 'Lab. ASM 2 (R.1.14)', 'Lab. ASM 3 (R.1.15)',
            'T. ASM 1 (R.1.16)', 'T. ASM 2 (R.2.19)',
            // DPIB
            'R. Gambar DPIB Lt.1', 'Lab. Komputer DPIB Lt.2',
            // RPL / Multimedia / KKPI
            'Lab. RPL 1', 'Lab. RPL 2', 'Lab. RPL 3', 'Lab. RPL 4',
            'Lab. Multimedia', 'Lab. KKP 1', 'Lab. KKPI 2',
            'Lab. B. Inggris 1', 'Lab. B. Inggris 2', 'Lab. B. Inggris 3',
            // Fasilitas umum (yang dipakai siswa)
            'Ruang Perpustakaan', 'Masjid', 'UKS', 'R. OSIS', 'Showroom',
            // Toilet
            'WC dekat Ruang Aula', 'WC dekat Rg 2.12',
        ];

        foreach ($locations as $name) {
            Location::firstOrCreate(['name' => $name]);
        }
    }
}

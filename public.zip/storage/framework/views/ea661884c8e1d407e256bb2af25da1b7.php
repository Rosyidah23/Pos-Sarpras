
<?php
    $belum = $counts['menunggu'] + $counts['diproses'];
    $sudah = $counts['selesai'] + $counts['ditolak'];
    $params = $params ?? [];
    $active = $active ?? null;
    $labels = ['menunggu' => 'Menunggu dicek', 'diproses' => 'Sedang diproses', 'selesai' => 'Sudah selesai', 'ditolak' => 'Ditolak'];
    $tones = ['menunggu' => 'yellow', 'diproses' => 'blue', 'selesai' => 'mint', 'ditolak' => 'coral'];
?>
<div class="sum-grid">
    <div class="sum sum-total">
        <small>Total laporan</small>
        <strong><?php echo e($counts->sum()); ?></strong>
        <span>Semua laporan yang masuk</span>
    </div>
    <div class="sum sum-pending">
        <small>Belum ditangani</small>
        <strong><?php echo e($belum); ?></strong>
        <span><?php echo e($counts['menunggu']); ?> menunggu · <?php echo e($counts['diproses']); ?> diproses</span>
    </div>
    <div class="sum sum-done">
        <small>Sudah ditangani</small>
        <strong><?php echo e($sudah); ?></strong>
        <span><?php echo e($counts['selesai']); ?> selesai · <?php echo e($counts['ditolak']); ?> ditolak</span>
    </div>
</div>
<div class="stats">
    <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="stat <?php echo e($active === $status ? 'stat-active' : ''); ?>" style="--tone:var(--<?php echo e($tones[$status]); ?>)"
           href="<?php echo e(route($route, array_merge($params, ['status' => $status]))); ?>">
            <i></i><strong><?php echo e($counts[$status]); ?></strong><small><?php echo e($label); ?></small>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/partials/status-summary.blade.php ENDPATH**/ ?>
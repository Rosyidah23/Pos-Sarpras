<?php $__env->startSection('title','Panel Petugas | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'admin.dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <header class="head">
            <div>
                <p class="eyebrow">PUSAT KENDALI PETUGAS</p>
                <h1>Semua laporan terlihat.</h1>
                <p>Atur laporan sampai selesai.</p>
            </div>
            <a class="btn primary" href="<?php echo e(route('admin.recap')); ?>">Rekap & Cetak</a>
        </header>

        <?php echo $__env->make('partials.status-summary', ['counts' => $counts, 'route' => 'admin.reports'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="reports-head">
            <h3>Laporan terbaru</h3>
            <a class="see-all" href="<?php echo e(route('admin.reports')); ?>">Verifikasi semua laporan →</a>
        </div>
        <div class="reports">
            <?php $__empty_1 = true; $__currentLoopData = $recentReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="report report-link" href="<?php echo e(route('admin.reports', ['status' => $report->status])); ?>#laporan-<?php echo e($report->id); ?>" title="Buka di Verifikasi Laporan">
                    <b><?php echo e($report->title); ?><small>#<?php echo e($report->code); ?> · <?php echo e($report->user->name ?? 'Tanpa nama'); ?></small>
                        <span class="report-desc"><?php echo e($report->description); ?></span>
                    </b>
                    <span class="tag" title="<?php echo e($report->category->name ?? '-'); ?>"><?php echo e($report->category->name ?? '-'); ?></span>
                    <span class="muted" title="<?php echo e($report->location->name ?? '-'); ?>"><?php echo e($report->location->name ?? '-'); ?></span>
                    <span class="status status-<?php echo e($report->status); ?>"><?php echo e(ucfirst($report->status)); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="report">
                    <b>Belum ada laporan masuk.<small>Laporan dari siswa akan muncul di sini.</small></b>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Riwayat Laporan | POS-SARPRAS'); ?>
<?php $__env->startSection('content'); ?>
<div class="shell">
    <?php echo $__env->make('partials.sidebar', ['active' => 'reports.history'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main">
        <header class="head">
            <div>
                <p class="eyebrow">RIWAYAT LAPORAN</p>
                <h1>Laporan kamu.</h1>
                <p>Semua laporan yang pernah kamu ajukan, beserta status penanganannya.</p>
            </div>
            <a class="btn primary" href="<?php echo e(route('reports.create')); ?>">Buat laporan baru ↗</a>
        </header>

        <?php if($errors->any()): ?>
            <p class="alert-error"><?php echo e($errors->first()); ?></p>
        <?php endif; ?>

        <?php echo $__env->make('partials.status-summary', ['counts' => $counts, 'route' => 'reports.history', 'params' => array_filter(['from' => $from, 'to' => $to]), 'active' => $statusFilter], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <form method="GET" action="<?php echo e(route('reports.history')); ?>" class="date-filter">
            <div class="field">
                <label for="from">Dari tanggal</label>
                <input id="from" type="date" name="from" value="<?php echo e($from); ?>">
            </div>
            <div class="field">
                <label for="to">Sampai tanggal</label>
                <input id="to" type="date" name="to" value="<?php echo e($to); ?>">
            </div>
            <?php if($statusFilter): ?>
                <input type="hidden" name="status" value="<?php echo e($statusFilter); ?>">
            <?php endif; ?>
            <button class="btn primary" type="submit">Tampilkan</button>
            <?php if($from || $to): ?>
                <a class="btn soft" href="<?php echo e(route('reports.history', array_filter(['status' => $statusFilter]))); ?>">Reset</a>
            <?php endif; ?>
        </form>
        <div class="filter-bar">
            <a class="chip <?php echo e(!$statusFilter ? 'chip-active' : ''); ?>" href="<?php echo e(route('reports.history', array_filter(['from' => $from, 'to' => $to]))); ?>">Semua (<?php echo e($counts->sum()); ?>)</a>
            <?php $__currentLoopData = \App\Models\Report::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="chip <?php echo e($statusFilter === $s ? 'chip-active' : ''); ?>" href="<?php echo e(route('reports.history', array_filter(['from' => $from, 'to' => $to, 'status' => $s]))); ?>"><?php echo e(ucfirst($s)); ?> (<?php echo e($counts[$s]); ?>)</a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <p class="filter-hint">
            <?php if($from || $to || $statusFilter): ?>
                <?php echo e($reports->total()); ?> laporan ditemukan. Kosongkan salah satu tanggal untuk menampilkan tanpa batas awal atau akhir.
            <?php else: ?>
                Menampilkan semua laporan. Isi tanggal untuk melihat riwayat pada periode tertentu.
            <?php endif; ?>
        </p>

        <div class="reports">
            <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="report <?php echo e($report->photo_path ? 'report-photo' : ''); ?>">
                    <?php if($report->photo_path): ?>
                        <button type="button" class="report-thumb-btn photo-zoom" data-full="<?php echo e(asset('storage/'.$report->photo_path)); ?>">
                            <img class="report-thumb" src="<?php echo e(asset('storage/'.$report->photo_path)); ?>" alt="Foto laporan">
                        </button>
                    <?php endif; ?>
                    <b><?php echo e($report->title); ?><small>#<?php echo e($report->code); ?> · <?php echo e($report->created_at->translatedFormat('d M Y')); ?></small>
                        <span class="report-desc" title="<?php echo e($report->description); ?>"><?php echo e($report->description); ?></span>
                        <?php if($report->follow_up_note): ?>
                            <span class="verify-note">Catatan petugas: <?php echo e($report->follow_up_note); ?></span>
                        <?php endif; ?>
                    </b>
                    <span class="tag" title="<?php echo e($report->category->name ?? '-'); ?>"><?php echo e($report->category->name ?? '-'); ?></span>
                    <span class="muted" title="<?php echo e($report->location->name ?? '-'); ?>"><?php echo e($report->location->name ?? '-'); ?></span>
                    <span class="status status-<?php echo e($report->status); ?>"><?php echo e(ucfirst($report->status)); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="report report-empty">
                    <?php if($from || $to): ?>
                        <b>Tidak ada laporan pada tanggal tersebut.<small>Coba ubah rentang tanggalnya.</small></b>
                    <?php else: ?>
                        <b>Belum ada laporan.<small>Laporan yang kamu ajukan akan muncul di sini.</small></b>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php echo $__env->make('partials.pager', ['paginator' => $reports], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pos-sarpras-laravel\resources\views/student/history.blade.php ENDPATH**/ ?>